import 'dotenv/config';
import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createServer as createViteServer } from 'vite';
import { AuthRequest, requireAuth } from './src/middleware/auth.ts';
import { updateUserName } from './src/db/users.ts';
import {
  createOrder,
  getOrdersForUser,
  getSavedLooks,
  subscribeNewsletter,
  toggleSavedLook,
} from './src/db/store.ts';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT) || 3000;

const CATALOG = [
  { name: 'Cobalt Shell', pieces: [{ name: 'Cobalt Rain Shell', price: 425 }, { name: 'Wide Cargo Pant', price: 165 }] },
  { name: 'Silver Signal', pieces: [{ name: 'Mirror Down Parka', price: 650 }, { name: 'Straight Tech Trouser', price: 180 }] },
  { name: 'Night Run', pieces: [{ name: 'Storm Hooded Shell', price: 390 }, { name: 'Wide Cargo Pant', price: 165 }] },
  { name: 'Long Hour', pieces: [{ name: 'Hooded Long Parka', price: 720 }, { name: 'Straight Tech Trouser', price: 180 }] },
  { name: 'Gallery Opening', pieces: [{ name: 'Quilted Down Vest', price: 310 }, { name: 'Graphite Cargo Pant', price: 175 }] },
  { name: 'Soft Static', pieces: [{ name: 'Graphite Fleece Half-Zip', price: 210 }, { name: 'Pleated Wide Trouser', price: 195 }] },
];

const VALID_SIZES = new Set(['S', 'M', 'L', 'XL']);
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

async function startServer() {
  const app = express();

  app.use((_req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    next();
  });

  app.use(express.json({ limit: '64kb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true });
  });

  app.post('/api/newsletter', async (req, res) => {
    try {
      const email = typeof req.body?.email === 'string' ? req.body.email.trim().toLowerCase() : '';
      if (!EMAIL_RE.test(email) || email.length > 120) {
        return res.status(400).json({ error: 'Please provide a valid email address.' });
      }
      await subscribeNewsletter(email);
      return res.json({ ok: true });
    } catch (error: unknown) {
      const msg = error instanceof Error ? error.message : 'Subscription failed.';
      return res.status(500).json({ error: msg });
    }
  });

  app.get('/api/account/me', requireAuth, async (req: AuthRequest, res) => {
    try {
      const dbUser = req.dbUser!;
      const [looks, userOrders] = await Promise.all([
        getSavedLooks(dbUser.id),
        getOrdersForUser(dbUser.id),
      ]);
      return res.json({
        profile: {
          uid: dbUser.uid,
          email: dbUser.email,
          name: dbUser.name,
        },
        savedLooks: looks,
        orders: userOrders.map((o) => ({
          id: o.orderCode,
          date: new Date(o.createdAt).toLocaleDateString(),
          email: o.customerEmail,
          total: o.totalCents / 100,
          status: o.status,
          items: JSON.parse(o.itemsJson),
        })),
      });
    } catch (error: unknown) {
      const msg = error instanceof Error ? error.message : 'Failed to load account.';
      return res.status(500).json({ error: msg });
    }
  });

  app.put('/api/account/profile', requireAuth, async (req: AuthRequest, res) => {
    try {
      const name = typeof req.body?.name === 'string' ? req.body.name.trim() : '';
      if (name.length < 2 || name.length > 60) {
        return res.status(400).json({ error: 'Name must be between 2 and 60 characters.' });
      }
      const updated = await updateUserName(req.dbUser!.id, name);
      return res.json({
        profile: {
          uid: updated.uid,
          email: updated.email,
          name: updated.name,
        },
      });
    } catch (error: unknown) {
      const msg = error instanceof Error ? error.message : 'Failed to update profile.';
      return res.status(500).json({ error: msg });
    }
  });

  app.post('/api/saved-looks/toggle', requireAuth, async (req: AuthRequest, res) => {
    try {
      const lookIndex = Number(req.body?.lookIndex);
      if (!Number.isInteger(lookIndex) || lookIndex < 0 || lookIndex >= CATALOG.length) {
        return res.status(400).json({ error: 'Invalid look index.' });
      }
      const result = await toggleSavedLook(req.dbUser!.id, lookIndex);
      return res.json(result);
    } catch (error: unknown) {
      const msg = error instanceof Error ? error.message : 'Failed to update saved looks.';
      return res.status(500).json({ error: msg });
    }
  });

  app.post('/api/orders', requireAuth, async (req: AuthRequest, res) => {
    try {
      const customerName = typeof req.body?.name === 'string' ? req.body.name.trim() : '';
      const customerEmail = typeof req.body?.email === 'string' ? req.body.email.trim().toLowerCase() : '';
      const shippingAddress = typeof req.body?.address === 'string' ? req.body.address.trim() : '';
      const rawItems = Array.isArray(req.body?.items) ? req.body.items : [];

      if (customerName.length < 2 || customerName.length > 60) {
        return res.status(400).json({ error: 'Please enter a valid full name.' });
      }
      if (!EMAIL_RE.test(customerEmail) || customerEmail.length > 120) {
        return res.status(400).json({ error: 'Please enter a valid email address.' });
      }
      if (shippingAddress.length < 6 || shippingAddress.length > 160) {
        return res.status(400).json({ error: 'Please enter a complete shipping address.' });
      }
      if (rawItems.length === 0 || rawItems.length > 24) {
        return res.status(400).json({ error: 'Your bag is empty or exceeds item limits.' });
      }

      const normalizedItems: Array<{
        lookIndex: number;
        pieceIndex: number;
        lookName: string;
        pieceName: string;
        size: string;
        qty: number;
        unitPriceCents: number;
      }> = [];

      const qtyByKey = new Map<string, number>();

      for (const item of rawItems) {
        const lookIndex = Number(item?.lookIndex);
        const pieceIndex = Number(item?.pieceIndex);
        const qty = Number(item?.qty);
        const size = typeof item?.size === 'string' && VALID_SIZES.has(item.size) ? item.size : 'M';

        if (
          !Number.isInteger(lookIndex) ||
          lookIndex < 0 ||
          lookIndex >= CATALOG.length ||
          (pieceIndex !== 0 && pieceIndex !== 1) ||
          !Number.isInteger(qty) ||
          qty < 1 ||
          qty > 10
        ) {
          return res.status(400).json({ error: 'Invalid bag item.' });
        }

        const look = CATALOG[lookIndex];
        const piece = look.pieces[pieceIndex];
        const key = `${lookIndex}-${pieceIndex}`;
        qtyByKey.set(key, (qtyByKey.get(key) || 0) + qty);

        normalizedItems.push({
          lookIndex,
          pieceIndex,
          lookName: look.name,
          pieceName: piece.name,
          size,
          qty,
          unitPriceCents: piece.price * 100,
        });
      }

      let subtotalCents = 0;
      for (const it of normalizedItems) {
        subtotalCents += it.unitPriceCents * it.qty;
      }

      let discountCents = 0;
      for (let i = 0; i < CATALOG.length; i++) {
        const q0 = qtyByKey.get(`${i}-0`) || 0;
        const q1 = qtyByKey.get(`${i}-1`) || 0;
        if (q0 > 0 && q1 > 0) {
          const pairs = Math.min(q0, q1);
          const lookSumCents = (CATALOG[i].pieces[0].price + CATALOG[i].pieces[1].price) * 100;
          discountCents += Math.round(lookSumCents * 0.1 * pairs);
        }
      }

      const totalCents = Math.max(0, subtotalCents - discountCents);
      const orderCode = 'KHB-' + Math.floor(100000 + Math.random() * 900000);

      await updateUserName(req.dbUser!.id, customerName);

      const created = await createOrder({
        orderCode,
        userId: req.dbUser!.id,
        customerName,
        customerEmail,
        shippingAddress,
        subtotalCents,
        discountCents,
        totalCents,
        itemsJson: JSON.stringify(normalizedItems),
      });

      const count = normalizedItems.reduce((s, it) => s + it.qty, 0);
      return res.status(201).json({
        order: {
          id: created.orderCode,
          date: new Date(created.createdAt).toLocaleDateString(),
          email: created.customerEmail,
          total: created.totalCents / 100,
          count,
          status: created.status,
          items: normalizedItems,
        },
      });
    } catch (error: unknown) {
      const msg = error instanceof Error ? error.message : 'Failed to place order.';
      return res.status(500).json({ error: msg });
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.join(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`KHUBAIB server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Server failed to start:', err);
  process.exit(1);
});
