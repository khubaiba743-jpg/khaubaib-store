import { and, desc, eq } from 'drizzle-orm';
import { db } from './index.ts';
import { newsletterSubscribers, orders, savedLooks } from './schema.ts';

export async function getSavedLooks(userId: number): Promise<number[]> {
  try {
    const rows = await db
      .select({ lookIndex: savedLooks.lookIndex })
      .from(savedLooks)
      .where(eq(savedLooks.userId, userId));
    return rows.map((r) => r.lookIndex);
  } catch (error) {
    console.error('Database query failed in getSavedLooks:', error);
    throw new Error('Failed to load saved looks.', { cause: error });
  }
}

export async function toggleSavedLook(userId: number, lookIndex: number): Promise<{ saved: boolean; looks: number[] }> {
  try {
    const existing = await db
      .select({ id: savedLooks.id })
      .from(savedLooks)
      .where(and(eq(savedLooks.userId, userId), eq(savedLooks.lookIndex, lookIndex)));

    let saved = false;
    if (existing.length > 0) {
      await db
        .delete(savedLooks)
        .where(and(eq(savedLooks.userId, userId), eq(savedLooks.lookIndex, lookIndex)));
    } else {
      await db.insert(savedLooks).values({ userId, lookIndex });
      saved = true;
    }

    const looks = await getSavedLooks(userId);
    return { saved, looks };
  } catch (error) {
    console.error('Database query failed in toggleSavedLook:', error);
    throw new Error('Failed to update saved looks.', { cause: error });
  }
}

export async function getOrdersForUser(userId: number) {
  try {
    return await db
      .select()
      .from(orders)
      .where(eq(orders.userId, userId))
      .orderBy(desc(orders.createdAt));
  } catch (error) {
    console.error('Database query failed in getOrdersForUser:', error);
    throw new Error('Failed to load orders.', { cause: error });
  }
}

export async function createOrder(input: {
  orderCode: string;
  userId: number;
  customerName: string;
  customerEmail: string;
  shippingAddress: string;
  subtotalCents: number;
  discountCents: number;
  totalCents: number;
  itemsJson: string;
}) {
  try {
    const result = await db
      .insert(orders)
      .values({
        orderCode: input.orderCode,
        userId: input.userId,
        customerName: input.customerName,
        customerEmail: input.customerEmail,
        shippingAddress: input.shippingAddress,
        subtotalCents: input.subtotalCents,
        discountCents: input.discountCents,
        totalCents: input.totalCents,
        itemsJson: input.itemsJson,
        status: 'confirmed',
      })
      .returning();
    return result[0];
  } catch (error) {
    console.error('Database query failed in createOrder:', error);
    throw new Error('Failed to place order.', { cause: error });
  }
}

export async function subscribeNewsletter(email: string) {
  try {
    await db
      .insert(newsletterSubscribers)
      .values({ email })
      .onConflictDoNothing({ target: newsletterSubscribers.email });
  } catch (error) {
    console.error('Database query failed in subscribeNewsletter:', error);
    throw new Error('Failed to register email.', { cause: error });
  }
}
