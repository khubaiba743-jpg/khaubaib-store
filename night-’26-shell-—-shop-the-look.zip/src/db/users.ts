import { eq } from 'drizzle-orm';
import { db } from './index.ts';
import { users } from './schema.ts';

export async function getOrCreateUser(uid: string, email: string, name?: string) {
  try {
    const cleanEmail = (email || '').slice(0, 120);
    const cleanName = (name || '').slice(0, 60);
    const result = await db
      .insert(users)
      .values({
        uid,
        email: cleanEmail,
        name: cleanName,
      })
      .onConflictDoUpdate({
        target: users.uid,
        set: {
          email: cleanEmail,
        },
      })
      .returning();

    return result[0];
  } catch (error) {
    console.error('Database query failed in getOrCreateUser:', error);
    throw new Error('Failed to synchronize user account.', { cause: error });
  }
}

export async function updateUserName(userId: number, name: string) {
  try {
    const result = await db
      .update(users)
      .set({ name: name.slice(0, 60) })
      .where(eq(users.id, userId))
      .returning();
    return result[0];
  } catch (error) {
    console.error('Database query failed in updateUserName:', error);
    throw new Error('Failed to update profile.', { cause: error });
  }
}
