import { onAuthStateChanged, signInWithPopup, signOut, User } from 'firebase/auth';
import { auth, googleAuthProvider } from './lib/firebase.ts';

let currentUser: User | null = null;
let idToken: string | null = null;
const listeners = new Set<(state: { user: User | null; signedIn: boolean }) => void>();

async function refreshToken(user: User | null) {
  currentUser = user;
  idToken = user ? await user.getIdToken() : null;
  listeners.forEach((cb) => cb({ user: currentUser, signedIn: Boolean(currentUser) }));
}

onAuthStateChanged(auth, (user) => {
  void refreshToken(user);
});

async function apiFetch<T>(url: string, options: RequestInit = {}): Promise<T> {
  const headers = new Headers(options.headers || {});
  headers.set('Content-Type', 'application/json');
  if (currentUser) {
    idToken = await currentUser.getIdToken();
    if (idToken) {
      headers.set('Authorization', `Bearer ${idToken}`);
    }
  }
  const res = await fetch(url, { ...options, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(typeof data?.error === 'string' ? data.error : 'Request failed');
  }
  return data as T;
}

declare global {
  interface Window {
    KHUBAIB_API: {
      isSignedIn: () => boolean;
      getUserInfo: () => { email: string; name: string } | null;
      onAuthChange: (cb: (state: { user: User | null; signedIn: boolean }) => void) => () => void;
      signInWithGoogle: () => Promise<{ email: string; name: string }>;
      signOutUser: () => Promise<void>;
      getAccountMe: () => Promise<{
        profile: { uid: string; email: string; name: string };
        savedLooks: number[];
        orders: Array<{ id: string; date: string; email: string; total: number; status: string }>;
      }>;
      updateProfile: (name: string) => Promise<{ profile: { uid: string; email: string; name: string } }>;
      toggleSavedLook: (lookIndex: number) => Promise<{ saved: boolean; looks: number[] }>;
      placeOrder: (payload: {
        name: string;
        email: string;
        address: string;
        items: Array<{ lookIndex: number; pieceIndex: number; size: string; qty: number }>;
      }) => Promise<{ order: { id: string; date: string; email: string; total: number; count: number } }>;
      subscribeNewsletter: (email: string) => Promise<{ ok: boolean }>;
    };
  }
}

window.KHUBAIB_API = {
  isSignedIn: () => Boolean(currentUser),
  getUserInfo: () =>
    currentUser
      ? {
          email: currentUser.email || '',
          name: currentUser.displayName || '',
        }
      : null,
  onAuthChange: (cb) => {
    listeners.add(cb);
    cb({ user: currentUser, signedIn: Boolean(currentUser) });
    return () => listeners.delete(cb);
  },
  signInWithGoogle: async () => {
    const result = await signInWithPopup(auth, googleAuthProvider);
    await refreshToken(result.user);
    return {
      email: result.user.email || '',
      name: result.user.displayName || '',
    };
  },
  signOutUser: async () => {
    await signOut(auth);
    await refreshToken(null);
  },
  getAccountMe: () => apiFetch('/api/account/me'),
  updateProfile: (name: string) =>
    apiFetch('/api/account/profile', {
      method: 'PUT',
      body: JSON.stringify({ name }),
    }),
  toggleSavedLook: (lookIndex: number) =>
    apiFetch('/api/saved-looks/toggle', {
      method: 'POST',
      body: JSON.stringify({ lookIndex }),
    }),
  placeOrder: (payload) =>
    apiFetch('/api/orders', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  subscribeNewsletter: (email: string) =>
    apiFetch('/api/newsletter', {
      method: 'POST',
      body: JSON.stringify({ email }),
    }),
};
